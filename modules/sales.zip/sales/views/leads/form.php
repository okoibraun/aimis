<?php
require_once '../../includes/helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../../../login.php');
    exit();
}

$is_edit = isset($_GET['id']);
$lead = ['customer_id'=>'','title'=>'','description'=>'','lead_date'=>'','status'=>'New','assigned_to'=>''];
$customers = get_all_rows('sales_customers');

if ($is_edit) {
    $lead = get_row_by_id('sales_leads', $_GET['id']);
}
?>
<!doctype html>
<html lang="en">
  <!--begin::Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AIMIS | Sales - Leads</title>
    <?php include_once("../../../../includes/head.phtml"); ?>
  </head>
  <!--end::Head-->
  <!--begin::Body-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
      <!--begin::Header-->
      <?php include_once("../../../../includes/header.phtml"); ?>
      <!--end::Header-->
      <!--begin::Sidebar-->
      <?php include_once("../../../../includes/sidebar.phtml"); ?>
      <!--end::Sidebar-->
      <!--begin::App Main-->
      <main class="app-main">
      <div class="app-content">
        <div class="container-fluid">


            <section class="content-header">
                <h1>
                    <?= $is_edit ? 'Edit' : 'Add' ?> Lead
                </h1>
            </section>

            <section class="content">
                <form action="../../controllers/leads.php" method="POST">
                    <input type="hidden" name="action" value="<?= $is_edit ? 'edit' : 'add' ?>">
                    <?php if ($is_edit): ?>
                    <input type="hidden" name="id" value="<?= $lead['id'] ?>">
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                            <label>Customer</label>
                            <select name="customer_id" class="form-control" required>
                                <option value="">Select</option>
                                <?php while ($c = $customers->fetch_assoc()): ?>
                                <option value="<?= $c['id'] ?>" <?= $c['id'] == $lead['customer_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['company_name']) ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                            </div>
                            <div class="form-group">
                            <label>Title</label>
                            <input name="title" class="form-control" value="<?= htmlspecialchars($lead['title']) ?>" required>
                            </div>
                            <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control"><?= htmlspecialchars($lead['description']) ?></textarea>
                            </div>
                            <div class="form-group">
                            <label>Lead Date</label>
                            <input type="date" name="lead_date" class="form-control" value="<?= $lead['lead_date'] ?>">
                            </div>
                            <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <?php foreach (['New', 'Contacted', 'Qualified', 'Lost', 'Won'] as $status): ?>
                                <option value="<?= $status ?>" <?= $lead['status'] === $status ? 'selected' : '' ?>><?= $status ?></option>
                                <?php endforeach; ?>
                            </select>
                            </div>
                            <div class="form-group">
                            <label>Assigned To (user ID)</label>
                            <input name="assigned_to" class="form-control" value="<?= $lead['assigned_to'] ?>">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-success">Save</button>
                            <a href="list.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </div>
                </form>
            </section>
            

        </div>
      </div>
      </main>
      <!--end::App Main-->
      <!--begin::Footer-->
      <?php include("../../../../includes/footer.phtml"); ?>
      <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <?php include("../../../../includes/scripts.phtml"); ?>
    <!--end::Script-->
  </body>
  <!--end::Body-->
</html>
