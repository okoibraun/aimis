<?php

redirect('../views/dashboard/index.php')