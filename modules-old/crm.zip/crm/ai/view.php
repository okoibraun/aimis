<?php
require_once '../../../config/db.php';
require_once '../../../functions/auth_functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../../login.php');
    exit();
}

$contact_id = intval($_GET['id']);

$stmt = $conn->prepare("
    SELECT c.first_name, c.last_name, i.*
    FROM crm_contacts c
    LEFT JOIN crm_lead_insights i ON c.id = i.contact_id
    WHERE c.id = ?
");
$stmt->bind_param("i", $contact_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
?>
<!doctype html>
<html lang="en">
  <!--begin::Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AIMIS | CRM - AI Insights</title>
    <?php include_once("../../../includes/head.phtml"); ?>
  </head>
  <!--end::Head-->
  <!--begin::Body-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
      <!--begin::Header-->
      <?php include_once("../../../includes/header.phtml"); ?>
      <!--end::Header-->
      <!--begin::Sidebar-->
      <?php include_once("../../../includes/sidebar.phtml"); ?>
      <!--end::Sidebar-->
      <!--begin::App Main-->
      <main class="app-main">
      <div class="app-content">
        <div class="container-fluid">
          

          <div class="content-wrapper">
            <section class="content-header">
              <h1>AI Insight for <?= htmlspecialchars($data['first_name'] . ' ' . $data['last_name']) ?></h1>
            </section>

            <section class="content">
              <div class="box">
                <div class="box-body">
                  <p><strong>Score:</strong> <?= $data['score'] ?> / 100</p>
                  <p><strong>Reason:</strong> <?= htmlspecialchars($data['score_reason']) ?></p>
                  <p><strong>Sentiment:</strong>
                    <span class="label label-<?= $data['sentiment'] === 'positive' ? 'success' : ($data['sentiment'] === 'negative' ? 'danger' : 'default') ?>">
                      <?= ucfirst($data['sentiment']) ?>
                    </span>
                  </p>
                  <p><strong>Summary:</strong> <?= htmlspecialchars($data['sentiment_summary']) ?></p>
                </div>
              </div>
            </section>
          </div>
          

        </div>
      </div>
      </main>
      <!--end::App Main-->
      <!--begin::Footer-->
      <?php include("../../../includes/footer.phtml"); ?>
      <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <?php include("../../../includes/scripts.phtml"); ?>
    <!--end::Script-->
    <script>
      $(function () {
        $('#leadsTable').DataTable();
      });
    </script>
  </body>
  <!--end::Body-->
</html>
