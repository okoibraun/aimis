<?php
$isEdit = isset($activity);
?>

<form method="POST" action="save.php">
  <?php if ($isEdit): ?>
    <input type="hidden" name="id" value="<?= $activity['id'] ?>">
  <?php endif; ?>

  <div class="form-group">
    <label>Type</label>
    <select name="type" class="form-control" required>
      <option value="call" <?= $isEdit && $activity['type'] == 'call' ? 'selected' : '' ?>>Call</option>
      <option value="meeting" <?= $isEdit && $activity['type'] == 'meeting' ? 'selected' : '' ?>>Meeting</option>
      <option value="email" <?= $isEdit && $activity['type'] == 'email' ? 'selected' : '' ?>>Email</option>
      <option value="note" <?= $isEdit && $activity['type'] == 'note' ? 'selected' : '' ?>>Note</option>
    </select>
  </div>

  <div class="form-group">
    <label>Subject</label>
    <input type="text" name="subject" class="form-control" required value="<?= $isEdit ? htmlspecialchars($activity['subject']) : '' ?>">
  </div>

  <div class="form-group">
    <label>Due Date</label>
    <input type="datetime-local" name="due_date" class="form-control" value="<?= $isEdit ? date('Y-m-d\TH:i', strtotime($activity['due_date'])) : '' ?>">
  </div>

  <div class="form-group">
    <label>Reminder At</label>
    <input type="datetime-local" name="reminder_at" class="form-control" value="<?= $isEdit && $activity['reminder_at'] ? date('Y-m-d\TH:i', strtotime($activity['reminder_at'])) : '' ?>">
  </div>

  <div class="form-group">
    <label>Related To</label>
    <div class="row">
      <div class="col-sm-6">
        <select name="related_type" class="form-control">
          <option value="contact" <?= $isEdit && $activity['related_type'] == 'contact' ? 'selected' : '' ?>>Contact</option>
          <option value="company" <?= $isEdit && $activity['related_type'] == 'company' ? 'selected' : '' ?>>Company</option>
          <option value="deal" <?= $isEdit && $activity['related_type'] == 'deal' ? 'selected' : '' ?>>Deal</option>
        </select>
      </div>
      <div class="col-sm-6">
        <input type="number" name="related_id" class="form-control" placeholder="Related Record ID" value="<?= $isEdit ? $activity['related_id'] : '' ?>">
      </div>
    </div>
  </div>

  <div class="form-group">
    <label>Assigned To (User ID)</label>
    <input type="number" name="assigned_to" class="form-control" required value="<?= $isEdit ? $activity['assigned_to'] : '' ?>">
  </div>

  <div class="form-group">
    <label>Status</label>
    <select name="status" class="form-control">
      <option value="pending" <?= $isEdit && $activity['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
      <option value="done" <?= $isEdit && $activity['status'] == 'done' ? 'selected' : '' ?>>Done</option>
    </select>
  </div>

  <div class="form-group">
    <label>Notes</label>
    <textarea name="notes" class="form-control"><?= $isEdit ? htmlspecialchars($activity['notes']) : '' ?></textarea>
  </div>

  <button type="submit" class="btn btn-success">Save</button>
  <a href="list.php" class="btn btn-default">Cancel</a>
</form>
