<?php
$isEdit = isset($contact);
?>

<form method="POST" action="save.php">
  <?php if ($isEdit): ?>
    <input type="hidden" name="id" value="<?= $contact['id'] ?>">
  <?php endif; ?>

  <div class="form-group">
    <label>Full Name</label>
    <input type="text" name="full_name" class="form-control" required value="<?= $isEdit ? htmlspecialchars($contact['full_name']) : '' ?>">
  </div>

  <div class="form-group">
    <label>Email</label>
    <input type="email" name="email" class="form-control" value="<?= $isEdit ? htmlspecialchars($contact['email']) : '' ?>">
  </div>

  <div class="form-group">
    <label>Phone</label>
    <input type="text" name="phone" class="form-control" value="<?= $isEdit ? htmlspecialchars($contact['phone']) : '' ?>">
  </div>

  <div class="form-group">
    <label>Job Title</label>
    <input type="text" name="job_title" class="form-control" value="<?= $isEdit ? htmlspecialchars($contact['job_title']) : '' ?>">
  </div>

  <div class="form-group">
    <label>Company</label>
    <select name="company_id" class="form-control">
      <option value="">-- Select Company --</option>
      <?php
      $stmt = $conn->prepare("SELECT id, name FROM crm_companies WHERE company_id = ?");
      $stmt->bind_param("i", $company_id);
      $stmt->execute();
      $companies = $stmt->get_result();
      while ($row = $companies->fetch_assoc()):
      ?>
        <option value="<?= $row['id'] ?>" <?= $isEdit && $contact['company_id'] == $row['id'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($row['name']) ?>
        </option>
      <?php endwhile; ?>
    </select>
  </div>

  <div class="form-group">
    <label>Notes</label>
    <textarea name="notes" class="form-control"><?= $isEdit ? htmlspecialchars($contact['notes']) : '' ?></textarea>
  </div>

  <button type="submit" class="btn btn-success">Save</button>
  <a href="list.php" class="btn btn-default">Cancel</a>
</form>
