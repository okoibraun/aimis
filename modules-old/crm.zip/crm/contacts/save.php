<?php
require_once '../../../config/db.php';
require_once '../../../functions/auth_functions.php';

$company_id = get_current_company_id();
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

$data = [
  'full_name'   => $_POST['full_name'],
  'email'       => $_POST['email'],
  'phone'       => $_POST['phone'],
  'job_title'   => $_POST['job_title'],
  'company_id'  => !empty($_POST['company_id']) ? intval($_POST['company_id']) : null,
  'notes'       => $_POST['notes'],
];

if ($id > 0) {
  $stmt = $conn->prepare("UPDATE crm_contacts SET full_name=?, email=?, phone=?, job_title=?, company_id=?, notes=? WHERE id=? AND company_id=?");
  $stmt->bind_param("ssssssii", $data['full_name'], $data['email'], $data['phone'], $data['job_title'], $data['company_id'], $data['notes'], $id, $company_id);
} else {
  $stmt = $conn->prepare("INSERT INTO crm_contacts (company_id, full_name, email, phone, job_title, company_id, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("issssis", $company_id, $data['full_name'], $data['email'], $data['phone'], $data['job_title'], $data['company_id'], $data['notes']);
}

$stmt->execute();
header("Location: list.php");
exit;
